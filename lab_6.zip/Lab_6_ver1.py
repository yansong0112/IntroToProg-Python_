
#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data (Step 4 & 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program Starts, load any data you have
# in a text file called ToDo.txt into Python Dictionary.
output_file = "ToDo.txt"
output_file = open(output_file, "w+")


# Step 2
# Display a menu of choices to the user
print ("""
    :1: Show current data
    :2: Add a new item
    :3: Remove an existing item
    :4: Save Data to File
    :5: Exit Program
    """)
print("Which option would you like to perform? [1 to 4] - ")

class ToDo:
    Task = None
    Priority = None
    lstTable = None
# Step 3
# Display all todo items to user
    def one():
        print("******** The current items ToDo are: ********")
        for row in lstTable:
            print(row["Task"] + row["Priority"] + ")")
        print("*********************************************")
        return
# Step 4
# Add a new item to the list/Table
    def two():
        print ("What is the task? - ")
        print ("What is the priority? [high/low] - ")
        dicRow = {"Task":None, "Priority":None}
        lstTable.append(dicRow)
        print("Current Data in Table:")
        for dicRow in lstTable:
            print(dicRow)
    #4a Show the current items in the table
        print("********** The current items ToDo are: **********")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*************************************************")
        return #to show the menu
# Step 5
# Remove a new item to the list/Table
    def three():
    #5a-Allow user to indicate which row to delete
        strKeytoRemove = ("Which TASK would you like removed? - ")
        blnItemRemoved = False
        intRowNumber = 0
        while(intRowNumber < len(lstTable)):
            if KeyToRemove == list(dict(lstTable[intRowNumber]).value())[0]:
                del lstTable[intRowNumber]
                blnItemRemove = True
        #end if
            intRowNumber += 1
        
    #5b-Update user on the status
        if(blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        
    #5c-Show the current items in the table
        print("********** The current items ToDo are: **********")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("************************************************")
        return #to show the menu
# Step 6
# Save tasks to the ToDo.txt file
    def four():
    #6a Show the current items in the table
        print("********** The current items ToDo are: **********")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*************************************************")
    #6b Ask if they want save that data
        if ("y" == "Save this data to file? (y/n) - ").strip().lower():
            f =open(output_file, "w")
            for dicRow in lstTable:
                f.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            output_file,close()
            print("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            print("New data was NOT saved, but previous data still exists! Press the [Enter]) key to return to menu.")
        return #to show the menu
# Step 7
# Exit program
    def five():
        return
print()
    
    



