def Todo_list():
    # create an empty list for ToDo list
    item = []

    print(Menu_of_Options())
    
    while True:
        # ask for things for the list
        item = input('>')
        
         # exit when DONE is entered
        if item.upper() == 'DONE':
            # quit
            break
        elif item.upper() == 'SHOW':
            # show the current list of items
            print(display_list(items))
        elif item.upper() == 'REMOVE':
            # remove items from the list
            print(remove_items(items))
            print('Add more items!')
        else:
            if item in items:
                print('"{}" already in list'.format(item))
                print('Add it again?')
                response = input('> ')
                if response.upper() == 'YES' or response.upper() == 'Y':
                    items.append(item)
            else:
                # add the item to the items list
                items.append(item)

    print(display_list(items))


def remove_items(items):
    print('Which items do you want to remove?')
    print("Type 'DONE' to exit.")
    while True:
        item = input('rmv > ')
        if item.upper() == 'DONE':
            break
        elif item in items:
            items.remove(item)
            print('Item "{}" removed for the list.'.format(item))
            print(display_list(items))
        elif item not in items:
            print('Item {} is not in the list.'.format(item))

def display_list(items):
    # tell the user how many items are in the list
    if len(items) == 0:
        string = 'There are no items in your list!'
    elif len(items) == 1:
        string = 'There is 1 item in your list:'
    else:
        string = 'There are {} items in your list:'.format(len(items))

    for item in items:
       # add a line feed and the the item
       string += '\n' + str(item)
    return string

def Menu_of_Options():
    string = """
Menu of options
1) Type 'SHOW' to show current data
2) Add a new item
3) Type 'REMOVE' to remove an existing item
4) Type 'SAVE' to save data to file
5) Type 'DONE' Exit Program
    """
    return string

if __name__ == '__main__':
    Todo_list()
    


